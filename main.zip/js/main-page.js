getDom("main-video").oncanplay = function() {
    getDom('main-section').style.backgroundSize = "0 0";
}