# js_move_setp_by_step

自己实现的步进式滚动 支持 触屏 鼠标滚轮 笔（chrome only）

实现了用类进行封装。

功能性函数：

stop() 停止监听

start() 开始监听

注意：同一目标元素总是执行最新的动作

兼容性：
  * chrome √
  * firefox √
  * edge chromium √
  * edge √
  * uc手机浏览器 √
  * chrome android √

目前手感完全统一，也消除了触控板异常的连续滚动问题

修复触屏滚动方向问题

目前版本为3.6
